package com.example.moisturedashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    private WebView dashboardWebView;
    private ProgressBar progressBar;
    private Button refreshButton, resetButton;
    private FloatingActionButton fabMenu;
    private boolean isMenuOpen = false;

    // Base Looker Studio dashboard URL
    private final String BASE_URL = "https://lookerstudio.google.com/reporting/976fa1e8-1bb2-4aae-860e-de7cb6b9511b";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        dashboardWebView = findViewById(R.id.dashboardWebView);
        progressBar = findViewById(R.id.progressBar);
        refreshButton = findViewById(R.id.refreshButton);
        resetButton = findViewById(R.id.resetButton);
        fabMenu = findViewById(R.id.fabMenu);

        // Configure WebView
        WebSettings webSettings = dashboardWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);

        // Set WebView Client
        dashboardWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                super.onPageFinished(view, url);
            }
        });

        // Load main Looker Studio page
        dashboardWebView.loadUrl(BASE_URL);

        // Floating button toggles menu visibility
        fabMenu.setOnClickListener(v -> toggleMenu());

        // Button actions
        refreshButton.setOnClickListener(v -> {
            dashboardWebView.reload();
            toggleMenu();
        });

        resetButton.setOnClickListener(v -> {
            dashboardWebView.loadUrl(BASE_URL);
            toggleMenu();
        });
    }

    // Function to show/hide menu buttons
    private void toggleMenu() {
        isMenuOpen = !isMenuOpen;
        int visibility = isMenuOpen ? View.VISIBLE : View.GONE;
        refreshButton.setVisibility(visibility);
        resetButton.setVisibility(visibility);
    }

    @Override
    public void onBackPressed() {
        if (dashboardWebView.canGoBack()) {
            dashboardWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
